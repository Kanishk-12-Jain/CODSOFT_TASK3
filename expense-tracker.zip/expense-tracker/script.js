const STORAGE_KEY="expenseflow_transactions_v1";
let transactions=JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");
let editingId=null;

const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(n);
const save=()=>localStorage.setItem(STORAGE_KEY,JSON.stringify(transactions));
const today=()=>new Date().toISOString().slice(0,10);

$("date").value=today();

function totals(){
  const income=transactions.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
  const expense=transactions.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);
  $("income").textContent=money(income); $("expense").textContent=money(expense); $("balance").textContent=money(income-expense);
  $("balanceHint").textContent=income-expense>=0?"You're in positive balance":"Expenses are higher than income";
}
function filtered(){
  const q=$("searchInput").value.toLowerCase(), cat=$("categoryFilter").value, type=$("typeFilter").value;
  return transactions.filter(t=>(!q||t.title.toLowerCase().includes(q)||(t.note||"").toLowerCase().includes(q))&&(cat==="all"||t.category===cat)&&(type==="all"||t.type===type)).sort((a,b)=>b.date.localeCompare(a.date)||b.created-a.created);
}
function renderTable(){
  const rows=filtered(), body=$("transactionBody"), empty=$("emptyTransactions");
  body.innerHTML="";
  empty.style.display=rows.length?"none":"block";
  rows.forEach(t=>{
    const tr=document.createElement("tr");
    tr.innerHTML=`<td class="title-cell">${esc(t.title)}<small>${esc(t.note||"")}</small></td>
      <td>${esc(t.category)}</td><td>${formatDate(t.date)}</td>
      <td><span class="pill ${t.type}">${t.type==="income"?"Income":"Expense"}</span></td>
      <td class="${t.type==="income"?"amount-income":"amount-expense"}">${t.type==="income"?"+":"−"}${money(t.amount)}</td>
      <td><div class="actions"><button class="icon-btn" data-edit="${t.id}" title="Edit">✎</button><button class="icon-btn" data-delete="${t.id}" title="Delete">×</button></div></td>`;
    body.appendChild(tr);
  });
}
function renderCategories(){
  const sums={}; transactions.filter(t=>t.type==="expense").forEach(t=>sums[t.category]=(sums[t.category]||0)+t.amount);
  const data=Object.entries(sums).sort((a,b)=>b[1]-a[1]).slice(0,6), max=data[0]?.[1]||1;
  $("categoryList").innerHTML=data.map(([cat,val])=>`<div class="cat-row"><span class="cat-name">${esc(cat)}</span><span class="cat-bar"><i style="width:${val/max*100}%"></i></span><span class="cat-value">${money(val)}</span></div>`).join("");
  $("emptyCategories").style.display=data.length?"none":"block";
}
function drawChart(){
  const c=$("financeChart"), ctx=c.getContext("2d"), rect=c.getBoundingClientRect(), dpr=devicePixelRatio||1;
  c.width=rect.width*dpr;c.height=rect.height*dpr;ctx.scale(dpr,dpr);
  const w=rect.width,h=rect.height,p={l:36,r:12,t:20,b:28}, innerW=w-p.l-p.r,innerH=h-p.t-p.b;
  ctx.clearRect(0,0,w,h);
  const isMonth=$("chartPeriod").value==="month", now=new Date(), groups=[];
  if(isMonth){
    const days=new Date(now.getFullYear(),now.getMonth()+1,0).getDate();
    for(let i=1;i<=days;i++)groups.push({label:String(i),income:0,expense:0});
    transactions.forEach(t=>{const d=new Date(t.date+"T00:00");if(d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()){const g=groups[d.getDate()-1];g[t.type==="income"?"income":"expense"]+=t.amount;}});
  }else{
    const map={};transactions.forEach(t=>{const key=t.date.slice(0,7);if(!map[key])map[key]={label:key,income:0,expense:0};map[key][t.type]+=t.amount});
    groups.push(...Object.values(map).sort((a,b)=>a.label.localeCompare(b.label)).slice(-8));
  }
  if(!groups.length){ctx.fillStyle="#9aa2b0";ctx.font="11px DM Sans";ctx.textAlign="center";ctx.fillText("Add transactions to see your chart",w/2,h/2);return}
  const max=Math.max(1,...groups.flatMap(g=>[g.income,g.expense]));
  ctx.strokeStyle=getComputedStyle(document.body).getPropertyValue("--line");ctx.lineWidth=1;
  for(let i=0;i<5;i++){const y=p.t+innerH*i/4;ctx.beginPath();ctx.moveTo(p.l,y);ctx.lineTo(w-p.r,y);ctx.stroke()}
  const draw=(key,color)=>{ctx.strokeStyle=color;ctx.lineWidth=2.5;ctx.beginPath();groups.forEach((g,i)=>{const x=p.l+(groups.length===1?innerW/2:i*innerW/(groups.length-1));const y=p.t+innerH-(g[key]/max)*innerH;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke()};
  draw("income","#16a66a");draw("expense","#e34d5a");
  ctx.fillStyle="#9aa2b0";ctx.font="8px DM Sans";ctx.textAlign="center";groups.forEach((g,i)=>{if(groups.length<=10||i%Math.ceil(groups.length/8)===0){const x=p.l+(groups.length===1?innerW/2:i*innerW/(groups.length-1));ctx.fillText(g.label,x,h-8)}});
}
function formatDate(s){return new Date(s+"T00:00").toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function render(){totals();renderTable();renderCategories();drawChart()}

function openModal(t=null){
  $("modal").classList.remove("hidden"); editingId=t?.id||null;
  $("transactionForm").reset(); $("date").value=t?.date||today(); $("category").value=t?.category||"Food";
  document.querySelector(`input[name="type"][value="${t?.type||"expense"}"]`).checked=true;
  $("title").value=t?.title||"";$("amount").value=t?.amount||"";$("note").value=t?.note||"";
  $("formError").textContent="";
}
function closeModal(){$("modal").classList.add("hidden");editingId=null}
$("openModalBtn").onclick=()=>openModal();$("closeModal").onclick=closeModal;
document.querySelector(".modal-backdrop").onclick=closeModal;

$("transactionForm").addEventListener("submit",e=>{
  e.preventDefault();
  const title=$("title").value.trim(),amount=Number($("amount").value),date=$("date").value;
  if(!title||!amount||amount<=0||!date){$("formError").textContent="Please complete all required fields.";return}
  const type=document.querySelector('input[name="type"]:checked').value;
  const data={id:editingId||crypto.randomUUID(),title,amount,date,category:$("category").value,note:$("note").value.trim(),type,created:editingId?(transactions.find(t=>t.id===editingId)?.created||Date.now()):Date.now()};
  if(editingId)transactions=transactions.map(t=>t.id===editingId?data:t);else transactions.push(data);
  save();render();closeModal();toast(editingId?"Transaction updated":"Transaction added");
});
$("transactionBody").addEventListener("click",e=>{
  const edit=e.target.closest("[data-edit]"),del=e.target.closest("[data-delete]");
  if(edit){const t=transactions.find(x=>x.id===edit.dataset.edit);if(t)openModal(t)}
  if(del){const id=del.dataset.delete;if(confirm("Delete this transaction?")){transactions=transactions.filter(t=>t.id!==id);save();render();toast("Transaction deleted")}}
});
["searchInput","categoryFilter","typeFilter","chartPeriod"].forEach(id=>$(id).addEventListener("input",render));
$("clearAllBtn").onclick=()=>{if(transactions.length&&confirm("Delete all stored transactions?")){transactions=[];save();render();toast("All data cleared")}};
window.addEventListener("resize",drawChart);
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
render();
