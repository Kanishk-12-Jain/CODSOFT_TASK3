# ExpenseFlow — Personal Expense Tracker

A complete responsive expense tracker built with **HTML, CSS and JavaScript**.

## Run in VS Code

1. Extract this folder.
2. Open `expense-tracker` in VS Code.
3. Open `index.html`.
4. Right-click the file and choose **Open with Live Server**.

No npm, Node.js, database, or backend is required.

## Features

- Responsive and user-friendly dashboard
- Add income and expense transactions
- Date, category, title, amount and optional notes
- Automatic balance, income and expense totals
- Transaction history
- Edit and delete transactions
- Search transactions
- Category-based filtering
- Income/expense type filtering
- Spending by category
- Income vs expense chart
- Local Storage persistence
- Clear all data option
- Mobile responsive layout
- Form validation
- No personal details are used
